
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { RestaurantRecommendation } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This case should ideally be handled by the environment providing the key.
  // If not, the app won't function correctly with Gemini.
  console.error("API_KEY for Gemini is not set in environment variables.");
  // In a real app, you might want to throw an error or display a persistent message.
}

const ai = new GoogleGenAI({ apiKey: API_KEY! }); // Use non-null assertion as API_KEY is expected
const model = 'gemini-2.5-flash-preview-04-17';

const constructPrompt = (location: string, foodCraving: string): string => {
  return `
Eres 'GastroGuía', un experto culinario local con un profundo conocimiento de la escena gastronómica mundial. Eres amigable, conocedor y te especializas en encontrar las joyas ocultas y los mejores lugares para comer según los gustos de cada persona.

Tu misión es recomendar tres restaurantes excelentes basados en dos datos clave que te proporcionará el usuario:
- Ubicación deseada: ${location}
- Tipo de comida o antojo: ${foodCraving}

Para cada recomendación, debes seguir estrictamente el siguiente formato, generando exactamente tres recomendaciones si es posible. Si solo encuentras una o dos de alta calidad, puedes listarlas.

1. **[Nombre del Restaurante]**
* **Ideal para:** [Breve descripción del tipo de comida y ambiente].
* **¿Por qué visitarlo?:** [Explicación de por qué coincide con el antojo del usuario y qué lo hace especial].
* **Plato estrella:** [Un plato icónico o muy recomendado del lugar].

2. **[Nombre del Restaurante]**
* **Ideal para:** [Breve descripción del tipo de comida y ambiente].
* **¿Por qué visitarlo?:** [Explicación de por qué coincide con el antojo del usuario y qué lo hace especial].
* **Plato estrella:** [Un plato icónico o muy recomendado del lugar].

3. **[Nombre del Restaurante]**
* **Ideal para:** [Breve descripción del tipo de comida y ambiente].
* **¿Por qué visitarlo?:** [Explicación de por qué coincide con el antojo del usuario y qué lo hace especial].
* **Plato estrella:** [Un plato icónico o muy recomendado del lugar].

Basa tus recomendaciones en tu conocimiento sobre restaurantes populares y bien valorados en esa zona. Mantén un tono entusiasta y servicial. Si no conoces la zona específica "${location}" con suficiente detalle para dar recomendaciones de calidad, o si el tipo de comida "${foodCraving}" es demasiado ambiguo para esa zona, indica amablemente algo como: "¡Hola! Soy GastroGuía. Para la zona de '${location}' y el antojo '${foodCraving}', me está costando un poco encontrar joyas ocultas con la información que tengo. ¿Podrías darme una ubicación un poco más general o especificar un tipo de cocina diferente? ¡Así podré afinar mis recomendaciones para ti!" No inventes restaurantes.
Prioriza la calidad sobre la cantidad. Si solo puedes recomendar con confianza uno o dos lugares, está bien.
Asegúrate que la respuesta siga EXACTAMENTE el formato especificado para cada restaurante.
`.trim();
};

export const parseRecommendations = (text: string): RestaurantRecommendation[] | string => {
  const trimmedText = text.trim();

  // Check for explicit "I don't know" messages based on prompt's fallback instruction
  const politeNoResultMessage = /me está costando un poco encontrar|ubicación un poco más general|no conozco la zona/i;
  if (politeNoResultMessage.test(trimmedText)) {
    return trimmedText;
  }

  const recommendations: RestaurantRecommendation[] = [];
  // Split by a pattern that looks for "NUMBER. **Restaurant Name**"
  const restaurantBlocks = trimmedText.split(/\n\s*(?=\d+\.\s*\*\*[\s\S]+?\*\*)/);

  for (const block of restaurantBlocks) {
    const cleanBlock = block.trim();
    if (!cleanBlock) continue;

    const nameMatch = cleanBlock.match(/^(?:\d+\.\s*)?\*\*(.+?)\*\*/);
    // Ensure captures are non-greedy and stop at the next field or end of block
    const idealForMatch = cleanBlock.match(/\*\s*\*\*Ideal para:\*\*\s*([\s\S]+?)(?=\n\s*\*\s*\*\*|$)/);
    const whyVisitMatch = cleanBlock.match(/\*\s*\*\*¿Por qué visitarlo\?:\*\*\s*([\s\S]+?)(?=\n\s*\*\s*\*\*|$)/);
    const starDishMatch = cleanBlock.match(/\*\s*\*\*Plato estrella:\*\*\s*([\s\S]+?)(?=\n\s*\*\s*\*\*|$)/);


    if (nameMatch && nameMatch[1] && idealForMatch && idealForMatch[1] && whyVisitMatch && whyVisitMatch[1] && starDishMatch && starDishMatch[1]) {
      recommendations.push({
        name: nameMatch[1].trim(),
        idealFor: idealForMatch[1].trim(),
        whyVisit: whyVisitMatch[1].trim(),
        starDish: starDishMatch[1].trim(),
      });
    }
  }

  if (recommendations.length > 0) {
    return recommendations;
  }
  
  // If no structured recommendations are found, but text exists, return the text.
  // This covers AI messages that are not the specific "I don't know" pattern but also not structured.
  return trimmedText;
};


export const fetchRestaurantRecommendations = async (location: string, foodCraving: string): Promise<RestaurantRecommendation[] | string> => {
  if (!API_KEY) {
    return "Error: La clave API de Gemini no está configurada. Por favor, contacta al administrador.";
  }
  try {
    const prompt = constructPrompt(location, foodCraving);
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        // temperature: 0.7, // Adjust for creativity vs. factuality if needed
      }
    });
    
    const responseText = response.text;
    if (!responseText) {
      return "No se recibió respuesta del servicio de recomendaciones. Inténtalo de nuevo.";
    }
    return parseRecommendations(responseText);
  } catch (error) {
    console.error("Error fetching recommendations from Gemini:", error);
    if (error instanceof Error) {
        if (error.message.includes("API key not valid")) {
             return "Error: La clave API proporcionada no es válida. Por favor, verifica la configuración.";
        }
         return `Error al contactar el servicio de recomendaciones: ${error.message}. Inténtalo más tarde.`;
    }
    return "Ocurrió un error desconocido al obtener recomendaciones. Por favor, inténtalo de nuevo.";
  }
};
