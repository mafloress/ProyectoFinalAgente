
import React, { useState } from 'react';
import Input from './components/Input';
import Button from './components/Button';
import RestaurantCard from './components/RestaurantCard';
import LoadingSpinner from './components/LoadingSpinner';
import Header from './components/Header';
import { fetchRestaurantRecommendations } from './services/geminiService';
import { RestaurantRecommendation, RecommendationResult } from './types';

const App: React.FC = () => {
  const [location, setLocation] = useState<string>('');
  const [foodCraving, setFoodCraving] = useState<string>('');
  const [recommendations, setRecommendations] = useState<RecommendationResult>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!location || !foodCraving) {
      setError('Por favor, completa ambos campos: ubicación y tipo de comida.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setRecommendations(null);

    try {
      const result = await fetchRestaurantRecommendations(location, foodCraving);
      setRecommendations(result);
    } catch (err) {
      // Error handling is now more detailed in geminiService,
      // but a catch-all here is still good practice.
      const errorMessage = err instanceof Error ? err.message : 'Ocurrió un error inesperado.';
      setError(`Error al obtener recomendaciones: ${errorMessage}`);
      setRecommendations(null);
    } finally {
      setIsLoading(false);
    }
  };

  const renderRecommendations = () => {
    if (isLoading) {
      return <LoadingSpinner />;
    }
    if (error) {
      return <p className="text-center text-red-600 bg-red-100 p-4 rounded-md">{error}</p>;
    }
    if (!recommendations) {
      return (
        <p className="text-center text-slate-600 text-lg py-8">
          Cuéntame dónde estás y qué te apetece comer, ¡y te encontraré las mejores opciones!
        </p>
      );
    }
    if (typeof recommendations === 'string') {
      // This is for messages like "I don't know" or parsing issues from Gemini
      return <p className="text-center text-slate-700 bg-amber-100 p-6 rounded-md leading-relaxed whitespace-pre-wrap">{recommendations}</p>;
    }
    if (recommendations.length === 0) {
      return <p className="text-center text-slate-600">No se encontraron recomendaciones para tu búsqueda. Intenta ser más específico o general.</p>;
    }
    return (
      <div className="grid grid-cols-1 md:grid-cols-1 lg:grid-cols-1 gap-6">
        {recommendations.map((rec, index) => (
          <RestaurantCard key={index} recommendation={rec} index={index}/>
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-amber-50 text-slate-800 flex flex-col items-center px-4">
      <div className="container mx-auto max-w-3xl py-8 md:py-12">
        <Header />
        
        <form onSubmit={handleSubmit} className="mt-8 p-6 md:p-8 bg-white shadow-xl rounded-xl space-y-6">
          <Input
            id="location"
            label="Ubicación deseada (ciudad, barrio, etc.)"
            type="text"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Ej: Palermo, Buenos Aires"
            required
          />
          <Input
            id="foodCraving"
            label="Tipo de comida o antojo"
            type="text"
            value={foodCraving}
            onChange={(e) => setFoodCraving(e.target.value)}
            placeholder="Ej: Pizza napolitana, Tacos al pastor, Sushi fresco"
            required
          />
          <Button type="submit" isLoading={isLoading}>
            {isLoading ? 'Buscando...' : 'Buscar Recomendaciones'}
          </Button>
        </form>

        <section aria-live="polite" className="mt-10 md:mt-12">
          {renderRecommendations()}
        </section>

        <footer className="text-center py-8 mt-12 text-slate-500 text-sm">
          <p>&copy; {new Date().getFullYear()} GastroGuía. Todos los derechos reservados.</p>
          <p className="mt-1">Recomendaciones impulsadas por IA.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
