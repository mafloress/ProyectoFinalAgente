
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="text-center py-8 md:py-12">
      <h1 className="text-5xl md:text-6xl font-bold text-orange-600">
        GastroGuía <span role="img" aria-label="plate emoji">🍽️</span>
      </h1>
      <p className="mt-4 text-lg md:text-xl text-slate-600 max-w-2xl mx-auto">
        Tu experto culinario personal. Dime dónde estás y qué te apetece, ¡y encontraré las joyas gastronómicas para ti!
      </p>
    </header>
  );
};

export default Header;
