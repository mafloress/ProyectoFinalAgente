
import React from 'react';
import { RestaurantRecommendation } from '../types';

interface RestaurantCardProps {
  recommendation: RestaurantRecommendation;
  index: number;
}

const RestaurantCard: React.FC<RestaurantCardProps> = ({ recommendation, index }) => {
  return (
    <div className="bg-white shadow-xl rounded-lg p-6 mb-6 transition-all duration-300 hover:shadow-2xl">
      <h3 className="text-2xl font-bold text-orange-600 mb-3">
        {index + 1}. {recommendation.name}
      </h3>
      <div className="space-y-3 text-slate-700">
        <p>
          <strong className="font-semibold text-slate-800">Ideal para:</strong> {recommendation.idealFor}
        </p>
        <p>
          <strong className="font-semibold text-slate-800">¿Por qué visitarlo?:</strong> {recommendation.whyVisit}
        </p>
        <p>
          <strong className="font-semibold text-slate-800">Plato estrella:</strong> {recommendation.starDish}
        </p>
      </div>
    </div>
  );
};

export default RestaurantCard;
