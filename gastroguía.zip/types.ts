
export interface RestaurantRecommendation {
  name: string;
  idealFor: string;
  whyVisit: string;
  starDish: string;
}

// This type will hold either an array of recommendations, a string message, or null initially.
export type RecommendationResult = RestaurantRecommendation[] | string | null;
